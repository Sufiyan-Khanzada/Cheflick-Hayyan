    <head>
        <link rel="stylesheet" href="css/footer.css">    
     </head>      
     <footer>
        <div class="container-width-adj">
            <div class="bottom-fot row">
                <div class="fotter-log space singupinfo col-md-1">                     
                </div>
                <div class="fotter-log desc singupinfo col-md-3">
                    <div class="fot-com-det">
                        <img src="img/Group-8871.png" ></img><br>
                        <span>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                        </span>
                        <h1>
                            Download App
                        </h1>
                        <img src="img/11-plc1gqcj5yaj5kyiv6d3di97509acd4r6531r8fffs.png" ></img><br>
                        <img src="img/Mask-Group-2196.png" ></img><br>
                        
                    </div>
                </div>
                <div class="fotter-log quick-link channel col-md-2">
                    <div class="fot-quick-lnk">
                        <h4>
                            QUICK LINKS
                        </h4>    
                        <ul class="fot fot-nav-link">
                            <li>
                                <a href="home.php" class="">Home</a>
                            </li>
                            <li>
                                <a href="about.php">About</a>
                            </li>
                            <li>
                                <a href="cookingstar.php">Cooking Star</a>
                            </li>
                            <li>
                                <a href="faq.php">FAQ</a>
                            </li>
                            <li>
                                <a href="affiliated-program.php">Affiliate Program</a>
                            </li>
                            <li>
                                <a href="contact.php">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="fotter-log legal linksinfo col-md-2">
                    <div class="fot-quick-legal">
                        <h4>
                            LEGAL
                        </h4>    
                        <ul class="fot fot-nav-link">
                            <li>
                                <a href="index.php" class="">Disclaimer</a>
                            </li>
                            <li>
                                <a href="#">Privacy Policy</a>
                            </li>
                            <li>
                                <a href="#">Terms and Conditions</a>
                            </li>
                            <li>
                                <a href="#">Customer Policy</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="fotter-log contact linksinfo col-md-3">
                    <div class="fot-con-desc">
                        <h4>
                            CONTACT
                        </h4>
                        <span>
                            <i class='bi bi-phone-fill'></i>
                            <a>+92 323 1234567</a>
                            <br>
                            <i  class='bi bi-envelope-fill'></i>
                            <a>info@cheflick.com</a>
                        </span>
                    </div>
                    <div class="fot-con-socail">
                        <i style='font-size:18px' class='bi bi-facebook'></i>
                        <i style='font-size:18px' class='bi bi-linkedin'></i>
                        <i style='font-size:18px' class='bi bi-instagram'></i>
                    </div>
                </div>
                <div class="fotter-log space singupinfo col-md-1">
                </div>
            </div>
            <div class="botton-fot-end row">
                <div class="col-md-12">
                    <div class="copyright">
                        <span>
                            2022 Copyrights Reserved | CheifLick
                        </span>
                    </div>                     
                </div>
            </div>       
        </div>
     
     </footer> 
     