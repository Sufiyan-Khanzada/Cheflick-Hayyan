<!DOCTYPE html>  
<html>  
     <head>
     <title>CHEFLICK</title>  

<?php 
  include 'linkweb.php';
  ?>
<link rel="stylesheet" href="css/about.css">
<!--   <style>-->
<!--       form {-->
<!--    border: 0px solid;-->
<!--    box-shadow: 0px 0px 0px 0px !important;-->
<!--    padding: 22px 22px 22px 22px;-->
<!--    border-radius: 25px;-->
<!--    height: 100%;-->
<!--    margin: 50px 0px;-->
<!--}-->
<!--   </style>-->

         <link rel="stylesheet" href="css/contact.css">
             
     </head>      
     
     <?php
        include 'header.php';
        ?>          
     <body>
        <script>
        </script>  
        <div class="container-width-adj">
            <section class="contact-bner-section">
                <div class="row cont-1" style="background-image: url(img/about/1.png);">
                    <div class="col-lg-12">
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                        <div class="col-md-8 bnr-sec">
                            <div class="tag-bner-sec">
                                <h2>Payment Form</h2>
                            </div>
                        </div>
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="contact-acs-section">
                <div class="row cont-2">
                    <div class="col">
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                        <div class="col-md-8 bnr-sec">
                            <div class="head-bner-sec">
                                <!--<h5>Get on board</h5>-->
                                <h2>PAYEMENT FORM</h2>
                                <form>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                               <div class="row">
                <div class="col-sm-12">
                    <div class="myCard">
                    <div class="row">
                        <div class="col-sm-6">
                            <p class="card-texttt">Sub Total</p>
                            <p class="card-texttt">Discount</p>
                            <p class="card-texttt">GST</p>
                            <p class="card-texttt">Total</p>
                        </div>
                        <div class="col-sm-6 text-end">
                            <p class="bold">Rs.6800</p>
                            <p class="bold">Rs.500</p>
                            <p class="bold">Rs.800</p>
                            <p class="bold">Rs.8100</p>
                        </div>
                    </div>
                    </div>
                        </div>
                        </div>
                                                
                                                
                                            </div>
                                            
                                           <div class="form-group col-md-6">
                                                <label for="howdidyoufindus">Apply Voucher</label>
                                                <input type="text" class="form-control" id="inputname4" placeholder="Name">
                                                <br>
                                                <label for="subject">Select Payement Method</label>
                                                <select id="subject" class="form-control">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                                </select>
                                                <br>
                                                <button type="submit" class="btn btn-primary btnsingin">Sign in</button>
                                            </div>
                                           
                                            
                                        </div>
                                    </form>
                            </div>
                        </div>
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                        <div class="col-md-8 widget-sec">
                            <div class="widget-one-sec">
                                
                            </div>
                        </div>
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                    </div>                
                </div>
            </section>  
           
            <!--<section class="contact-sonl-section">-->
            <!--    <div class="row cont-4" style="background-image: url(img/home/15.png);">-->
            <!--        <div class="col-lg-12">-->
            <!--            <div class="col-sm-2">        -->
            <!--                <div class="space"></div>-->
            <!--            </div>-->
            <!--            <div class="col-md-8 sonl-sec">-->
            <!--                <div class="tag-sonl-sec">-->
            <!--                    <h2>Subscribe Our News Letter</h2>-->
            <!--                    <p>By entering my email below, I agree Cheflick can send me emailsfor promotions,-->
            <!--                        newsletters, blogs, discounts, updates and announcements.By subscribing I agree to the terms and conditions and privacy policy of Cheflick</p>-->
            <!--                    <input class="input-field inpu-email" type="text" placeholder="Email" name="usrnm"> <i class="fa fa-envelope icon email"></i><br><button class="sonl-readmore">Send Mail</button>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--            <div class="col-sm-2">        -->
            <!--                <div class="space"></div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</section>-->
        </div>
     </body>
     <?php
         include 'fotter.php';
        ?>
</html> 