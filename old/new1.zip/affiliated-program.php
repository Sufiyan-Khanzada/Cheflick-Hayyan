<!DOCTYPE html>  
<html>  
     <head>
     <title>CHEFLICK</title>  

<?php 
  include 'linkweb.php';
  ?>
         <link rel="stylesheet" href="css/afp.css">
             
     </head>      
     
     <?php
        include 'header.php';
        ?>               
     <body>
        <script>
        </script>  
        <div class="container-width-adj">
            <section class="affiliated-bner-section">
                <div class="row cont-1" style="background-image: url(img/about/1.png);">
                    <div class="col-lg-12">
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                        <div class="col-md-8 bnr-sec">
                            <div class="tag-bner-sec">
                                <h2>AFFLIATE PROGRAM</h2>
                            </div>
                        </div>
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="affiliated-acs-section">
                <div class="row cont-2">
                    <div class="col-md-6 acs-sec">
                        <div class="tag-acs-sec">
                            <h5>EARN AND REFER</h5>
                            <h2>AFFILIATE PROGRAM</h2>
                            <p>Refer us a chef and get prizes n vouchers upon their smooth on boarding with us. This program is made to help you support your friends with interest in cooking, also in the mean while we make sure anyone who have refered get to have something as well.</p>
                            <button class="acs-readmore"><a href="singup.php" style="color:white">Register Now</a></button>
                        </div>    
                    </div>
                    <div class="col-md-6 acs-img-sec">
                        <div class="acs-img-cont">
                            <img src="img/Mask-Group-21931.png" style="width: 40%;">
                        </div>
                    </div>
                </div>
            </section>  
            <section class="affiliated-sonl-section">
                <div class="row cont-3" style="background-image: url(img/home/15.png);">
                    <div class="col-lg-12">
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                        <div class="col-md-8 sonl-sec">
                            <div class="tag-sonl-sec">
                                <h2>Subscribe Our News Letter</h2>
                                <p>By entering my email below, I agree Cheflick can send me emailsfor promotions,
                                    newsletters, blogs, discounts, updates and announcements.By subscribing I agree to the terms and conditions and privacy policy of Cheflick</p>
                                <input class="input-field inpu-email" type="text" placeholder="Email" name="usrnm"> <i class="fa fa-envelope icon email"></i><br><button class="sonl-readmore">Send Mail</button>
                            </div>
                        </div>
                        <div class="col-sm-2">        
                            <div class="space"></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
     </body>
     <?php
         include 'fotter.php';
        ?>
</html> 